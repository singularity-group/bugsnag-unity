
#ifndef very_crashy_h
#define very_crashy_h

extern "C" void crashy_signal_runner(float num);

#endif
